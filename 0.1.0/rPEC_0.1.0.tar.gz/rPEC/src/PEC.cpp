//[[Rcpp::plugins(openmp)]]
// [[Rcpp::depends(RcppArmadillo)]]

#include <RcppArmadillo.h>
#include <omp.h>
#include <stdio.h>
#include <numeric>

using namespace Rcpp;
using namespace std;
using namespace arma;

// [[Rcpp::export]]
arma::mat match_parent(arma::mat offspring, arma::mat sire, int window_size=5,int cpu_cores=5){	
	omp_set_num_threads(cpu_cores);
	int SNP_n=offspring.n_rows;	
	int Window_n=SNP_n/window_size;
	
	int sire_n=(sire.n_cols)/2;
	int offspring_n=(offspring.n_cols)/2;
	int i,j,k;
	mat score(offspring_n,sire_n);
	score.fill(0);
	mat socre_left(offspring_n,sire_n),socre_right(offspring_n,sire_n);
	socre_left.fill(0),socre_right.fill(0);
	vec offspring_1_set,offspring_2_set,sire_1_set,sire_2_set;
	uvec off_1_sire_1,off_1_sire_2,off_2_sire_1,off_2_sire_2;

#pragma omp parallel for private(i,j,k,offspring_1_set,offspring_2_set,sire_1_set,sire_2_set,off_1_sire_1,off_1_sire_2,off_2_sire_1,off_2_sire_2)
for ( k=0;k<offspring_n;k++){	
	for( i=0; i < Window_n; i++){
		offspring_1_set=offspring(span(i*window_size,(i+1)*window_size-1),2*k).col(0);
		offspring_2_set=offspring(span(i*window_size,(i+1)*window_size-1),2*k+1).col(0);
		for( j=0; j < sire_n; j++){
			sire_1_set=sire(span(i*window_size,(i+1)*window_size-1),2*j).col(0);
			sire_2_set=sire(span(i*window_size,(i+1)*window_size-1),2*j+1).col(0);
			
				
				//left 染色体
				if(approx_equal(offspring_1_set,sire_1_set,"absdiff", 0)){
				socre_left(k,j)=socre_left(k,j)+1;
			    }else if(approx_equal(offspring_1_set,sire_2_set,"absdiff", 0)){
				socre_left(k,j)=socre_left(k,j)+1;
			    }

				//right 染色体
				if(approx_equal(offspring_2_set,sire_1_set,"absdiff", 0)){
				socre_right(k,j)=socre_right(k,j)+1;
			    }else if(approx_equal(offspring_2_set,sire_2_set,"absdiff", 0)){
				socre_right(k,j)=socre_right(k,j)+1;
			    }				
	   }
   }
}
#pragma omp parallel for private(i,j)
		for(i=0;i<offspring_n;i++){			
			for(j=0; j < sire_n; j++){				
				score(i,j)=std::max(socre_left(i,j),socre_right(i,j));
			}
		    }		
		return score;
}
