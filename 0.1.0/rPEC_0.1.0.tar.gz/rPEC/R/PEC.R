##R包PEC封装
##提供vcf文件,训练群id，验证群id
PEC<-function(vcf_file_name=NULL,
              hap_file_name=NULL,
			  sample_file_name=NULL,
              valid_id=NULL,
			  train_id=NULL,
			  return_result=TRUE,
			  output_file_name="match_parent",
			  win_size=10,
			  threads=30){
			  if (!require('data.table')) install.packages('data.table')
			  if (!require('stringr')) install.packages('stringr')
			  
			  #提供vcf格式文件
			  if(!is.null(vcf_file_name)){
			  #记录起始时间
			  star_time <- Sys.time()
			  #vcf文件格式转换
			  vcf_file=fread(vcf_file_name,data.table=F)
			  valid_vcf=vcf_file[,match(valid_id,colnames(vcf_file))]
			  train_vcf=vcf_file[,match(train_id,colnames(vcf_file))]
			  valid_vcf=as.matrix(valid_vcf)
			  train_vcf=as.matrix(train_vcf)
			  valid_vcf_two=matrix(NA,nrow(valid_vcf),ncol(valid_vcf)*2)
			  train_vcf_two=matrix(NA,nrow(train_vcf),ncol(train_vcf)*2)
			  i=1:ncol(valid_vcf)
			  j=1:ncol(train_vcf)
			  valid_vcf_two[,2*i-1]=str_sub(valid_vcf,1,1)
			  valid_vcf_two[,2*i]=str_sub(valid_vcf,3,3)
			  train_vcf_two[,2*j-1]=str_sub(train_vcf,1,1)
			  train_vcf_two[,2*j]=str_sub(train_vcf,3,3)
			  valid_vcf_two=apply(valid_vcf_two,2,as.numeric)
			  train_vcf_two=apply(train_vcf_two,2,as.numeric)
			  chrom=vcf_file[,1]
			  }
			  
			  #提供hap和sample格式文件
			  if(!is.null(hap_file_name)){
			  star_time <- Sys.time()
			  hap_file=fread(hap_file_name,data.table=F)
			  sample_file=fread(sample_file_name,data.table=F)
			  hap_file_1=hap_file[,-(1:5)]
			  sample_file_1=sample_file[-1,1:2]
			  sample_file_2=matrix(NA,1,nrow(sample_file_1)*2)
			  i=1:nrow(sample_file_1)
			  sample_file_2[,2*i-1]=t(sample_file_1[,1])
			  sample_file_2[,2*i]=t(sample_file_1[,1])
			  valid_id_order=rbind(match(valid_id,sample_file_2),match(valid_id,sample_file_2)+1)
			  valid_id_order=as.vector(valid_id_order)
			  train_id_order=rbind(match(train_id,sample_file_2),match(train_id,sample_file_2)+1)
			  train_id_order=as.vector(train_id_order)
			  valid_vcf_two=hap_file_1[,valid_id_order]
			  train_vcf_two=hap_file_1[,train_id_order]
			  chrom=hap_file[,1]
			  }
			  

			  #程序运行
			  print("start to match parent")
			  b=0
			  pb=txtProgressBar(style=3)
			  for(n in 1:length(unique(chrom))){
			  setTxtProgressBar(pb, n/length(unique(chrom)))
			  valid_vcf_two_1=valid_vcf_two[chrom==n,]
			  train_vcf_two_1=train_vcf_two[chrom==n,]
			  snp=match_parent(offspring=as.matrix(valid_vcf_two_1),sire=as.matrix(train_vcf_two_1),window_size=win_size,cpu_cores=threads)
			  b=b+snp
			  }
			  close(pb)
			  colnames(b)=train_id
			  rownames(b)=valid_id
			  print("finish summing window number")
			  
			  a=b
			  pb=txtProgressBar(style=3)
			  for(n in 1:nrow(b)){
			  setTxtProgressBar(pb, n/nrow(b))
			  a[n,]=colnames(b[,order(b[n,],decreasing=T)])
			  }
			  close(pb)
			  
			  print("finish matching parent")
			  
			  output_file=list(window_number=b,parent_order=a)
			  colnames(output_file$parent_order)=1:ncol(output_file$parent_order)
			  
			  end_time <- Sys.time()
			  run_time <- end_time - star_time
			  print(run_time)
			  
			  write.table(output_file$parent_order[,1],paste(output_file_name,".txt",sep=""),row.names=TRUE,quote=F,sep=" ")
			  
			  if(return_result) return(output_file)
			  }
			  
			  
